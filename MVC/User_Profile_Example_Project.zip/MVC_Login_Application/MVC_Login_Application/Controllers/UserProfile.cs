﻿namespace MVC_Login_Application.Controllers
{
    public class UserProfile
    {

    }
}