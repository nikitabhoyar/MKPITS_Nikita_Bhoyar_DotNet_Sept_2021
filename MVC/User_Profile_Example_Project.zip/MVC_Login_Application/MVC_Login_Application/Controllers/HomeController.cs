﻿using MVC_Login_Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Login_Application.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]

        public object Login(UserProfile objUser)
        {
            if(ModelState.IsValid)
            {
                using (EmployeeDBEntities db = new EmployeeDBEntities())
                {
                    var obj = db.UserProfiles.Where(a = > a.UserName.Equals(objUser.UserName) &&
                        a.Paasword.Equals(objUser.Password)).FirstOrDefault();
                    if(obj ! = null)
                    {
                        Session["UserID"] - obj.UserId.ToString()
                        Session["UserName"] - obj.UserId.ToString();
                        return RedirectToAction("UserDashBoard");
                    }

                    return View(objUser);

                }
            }
        }
    }
}