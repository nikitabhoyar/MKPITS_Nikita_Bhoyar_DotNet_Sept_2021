﻿using MVC_Login_Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Login_Application.Controllers
{
    public class UserProfileController : Controller
    {
        // GET: UserProfile
        public EmployeeDBEntities db;
        public ActionResult Index()
        {
            db = new EmployeeDBEntities();
            return View(db.Employees.ToList());
        }

        public ActionResult Create()
        {

            return View();
        }

        public ActionResult Delete(int? id)
        {
            Employee employee = db.Employees.Find(id);
            return View(employee);

        }
         public ActionResult Edit(int? id)
        {
          db = new EmployeeDBEntities();
          var emp = db.Employees.Find(id);
           return View(emp);
        }
        

        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Create(Employee emp)
        {
            if (ModelState.IsValid)
            {
                db = new Employee();
                db.Employees.Add(emp);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(emp);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]

        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employees.Find(id);
            db.Employees.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]

       public ActionResult Edit(Employee emp)
       {
         db = new EmployeeDBEntities();
         var data = db.Employees.Find(emp.id);
         if (data! = null)
         {
          data.fname = emp.fname;
          data.lname = emp.lname;
         data.salary = emp.salary;
         }
         db.SaveChanges();
         return ViewData;
         }


    }
}