﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication_MVC.Models;

namespace WebApplication_MVC.Controllers
{
    public class HomeController : Controller
    {
        myDBEntities db;
        public ActionResult Index()
        {
            ViewData["Name"] = "Nikita Bhoyar";
            ViewBag.role = "Software Engineer";
            return View();
          
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Events()
        {
            ViewBag.Message = "Your events page.";
            return View();
        }
    }
}