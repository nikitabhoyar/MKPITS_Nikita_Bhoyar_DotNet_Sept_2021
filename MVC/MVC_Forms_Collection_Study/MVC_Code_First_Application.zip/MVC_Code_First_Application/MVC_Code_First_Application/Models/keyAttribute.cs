﻿using System;

namespace MVC_Code_First_Application.Models
{
    internal class keyAttribute : Attribute
    {
    }
}