﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_Code_First_Application.Models
{
    public class Student
    {
        [key]
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int Marks { get; set; }
    }
}